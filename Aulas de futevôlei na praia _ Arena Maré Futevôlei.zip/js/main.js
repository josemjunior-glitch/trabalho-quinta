// Menu, botão de tema, carrossel, filtro de horários e painel de acessibilidade.
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];

// Menu no celular
const menuBtn = $(".menu-btn");
if (menuBtn) menuBtn.addEventListener("click", () => {
  const aberto = $("#menu").classList.toggle("aberto");
  menuBtn.setAttribute("aria-expanded", aberto);
});

// Alternar claro/escuro em qualquer página
const temaBtn = $("#tema-rapido");
function rotuloTema() {
  if (temaBtn) temaBtn.textContent = Prefs.temaEfetivo(Prefs.atual) === "escuro" ? "Modo claro" : "Modo escuro";
}
if (temaBtn) temaBtn.addEventListener("click", () => {
  Prefs.salvar({ tema: Prefs.temaEfetivo(Prefs.atual) === "escuro" ? "claro" : "escuro" });
  rotuloTema(); marcarOpcoes();
});

// Carrossel
const car = $(".carrossel");
if (car) {
  const slides = $$(".slide", car), pontos = $(".pontos"), pausa = $("#pausa");
  let atual = 0, timer = null;
  const semMovimento = Prefs.atual.movimento === "reduzido" || matchMedia("(prefers-reduced-motion: reduce)").matches;
  let tocando = !semMovimento;

  slides.forEach((_, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.setAttribute("aria-label", `Ir para a imagem ${i + 1}`);
    b.addEventListener("click", () => { mostrar(i); parar(); });
    pontos.append(b);
  });
  function mostrar(i) {
    atual = (i + slides.length) % slides.length;
    slides.forEach((s, n) => s.classList.toggle("ativo", n === atual));
    $$("button", pontos).forEach((b, n) => b.setAttribute("aria-current", n === atual));
  }
  function tocar() {
    clearInterval(timer);
    timer = setInterval(() => mostrar(atual + 1), 6000);
    tocando = true; pausa.textContent = "Pausar";
  }
  function parar() { clearInterval(timer); tocando = false; pausa.textContent = "Reproduzir"; }

  $("#anterior").addEventListener("click", () => { mostrar(atual - 1); parar(); });
  $("#proximo").addEventListener("click", () => { mostrar(atual + 1); parar(); });
  pausa.addEventListener("click", () => tocando ? parar() : tocar());
  $("#destaques").addEventListener("keydown", e => {
    if (e.key === "ArrowLeft") { mostrar(atual - 1); parar(); }
    if (e.key === "ArrowRight") { mostrar(atual + 1); parar(); }
  });
  $("#destaques").addEventListener("focusin", e => { if (e.target !== pausa) parar(); });
  car.addEventListener("mouseenter", () => clearInterval(timer));
  car.addEventListener("mouseleave", () => { if (tocando) tocar(); });
  mostrar(0);
  tocando ? tocar() : parar();
}

// Filtro de horários por nível
$$("[data-filtro]").forEach(btn => btn.addEventListener("click", () => {
  const nivel = btn.dataset.filtro;
  $$("[data-filtro]").forEach(b => b.setAttribute("aria-pressed", b === btn));
  let n = 0;
  $$("#grade tbody tr").forEach(tr => {
    tr.hidden = nivel !== "todos" && tr.dataset.nivel !== nivel;
    if (!tr.hidden) n++;
  });
  $("#resultado").textContent = `${n} turma(s) exibida(s).`;
}));

// Simulação de agendamento da aula experimental (nada é enviado)
const formAula = $("#form-aula");
if (formAula) formAula.addEventListener("submit", e => {
  e.preventDefault();
  $("#confirmacao").textContent = `Pronto, ${formAula.nome.value.trim()}! Simulação de aula ${formAula.nivel.value.toLowerCase()} registrada. Nenhum dado foi enviado.`;
});

// Painel de acessibilidade
function marcarOpcoes() {
  $$("[data-pref]").forEach(b => b.setAttribute("aria-pressed", String(Prefs.atual[b.dataset.pref]) === b.dataset.valor));
  const e = $("#valor-escala");
  if (e) {
    e.textContent = Prefs.atual.escala + "%";
    $("#menor").disabled = Prefs.atual.escala <= 100;
    $("#maior").disabled = Prefs.atual.escala >= 150;
  }
}
function anunciar(msg) { const s = $("#status"); if (s) s.textContent = msg; }
$$("[data-pref]").forEach(b => b.addEventListener("click", () => {
  Prefs.salvar({ [b.dataset.pref]: b.dataset.valor });
  marcarOpcoes(); rotuloTema(); anunciar("Preferência salva: " + b.textContent);
}));
[["#menor", -12.5], ["#maior", 12.5]].forEach(([id, passo]) => {
  const b = $(id);
  if (b) b.addEventListener("click", () => {
    Prefs.salvar({ escala: Math.min(150, Math.max(100, Prefs.atual.escala + passo)) });
    marcarOpcoes(); anunciar("Tamanho da fonte: " + Prefs.atual.escala + "%");
  });
});
const restaurar = $("#restaurar");
if (restaurar) restaurar.addEventListener("click", () => {
  Prefs.salvar({ ...PADRAO }); marcarOpcoes(); rotuloTema(); anunciar("Preferências restauradas.");
});

rotuloTema(); marcarOpcoes();
