// Aplica as preferências salvas ANTES de a página aparecer (evita "piscar").
const PADRAO = { tema:"auto", contraste:"normal", escala:100, fonte:"padrao", espaco:"normal", links:"normal", movimento:"normal" };
const Prefs = {
  ler() {
    try { return { ...PADRAO, ...JSON.parse(localStorage.getItem("arena-prefs")) }; }
    catch { return { ...PADRAO }; }
  },
  temaEfetivo(p) {
    if (p.tema !== "auto") return p.tema;
    return matchMedia("(prefers-color-scheme: dark)").matches ? "escuro" : "claro";
  },
  aplicar(p) {
    const r = document.documentElement;
    r.dataset.tema = this.temaEfetivo(p);
    ["contraste","fonte","espaco","links","movimento"].forEach(k => r.dataset[k] = p[k]);
    r.style.setProperty("--escala", p.escala + "%");
  },
  salvar(mudanca) {
    const p = { ...(this.atual || this.ler()), ...mudanca };
    this.atual = p;
    try { localStorage.setItem("arena-prefs", JSON.stringify(p)); } catch {}
    this.aplicar(p);
    return p;
  }
};
Prefs.atual = Prefs.ler();
Prefs.aplicar(Prefs.atual);
