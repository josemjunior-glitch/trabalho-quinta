// Área do aluno: meta semanal de treinos (engajamento), salva só no navegador.
// Sem login de demonstração, volta para a tela de entrada (não é segurança real).
try { if (!sessionStorage.getItem("arena-logado")) location.replace("login.html"); } catch {}
const META = 3;
const DIAS = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
let feitos = [];
try { feitos = JSON.parse(localStorage.getItem("arena-treinos")) || []; } catch {}

const area = document.querySelector("#dias");
DIAS.forEach(dia => {
  const b = document.createElement("button");
  b.type = "button"; b.className = "btn-a btn-b"; b.textContent = dia;
  b.setAttribute("aria-pressed", feitos.includes(dia));
  b.addEventListener("click", () => {
    feitos = feitos.includes(dia) ? feitos.filter(d => d !== dia) : [...feitos, dia];
    b.setAttribute("aria-pressed", feitos.includes(dia));
    try { localStorage.setItem("arena-treinos", JSON.stringify(feitos)); } catch {}
    atualizar();
  });
  area.append(b);
});

function atualizar() {
  const pct = Math.min(100, Math.round(feitos.length / META * 100));
  document.querySelector("#barra").style.width = pct + "%";
  document.querySelector(".progresso").setAttribute("aria-valuenow", pct);
  document.querySelector("#resumo").textContent = feitos.length >= META
    ? `Meta batida! ${feitos.length} treino(s) nesta semana.`
    : `${feitos.length} de ${META} treinos. Faltam ${META - feitos.length}.`;
}
document.querySelector("#sair").addEventListener("click", () => {
  try { sessionStorage.removeItem("arena-logado"); } catch {}
  location.href = "login.html";
});
atualizar();
