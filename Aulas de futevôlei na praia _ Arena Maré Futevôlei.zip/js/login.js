// Login de DEMONSTRAÇÃO: nada é enviado a servidor e a senha não é armazenada.
const DEMO = { email: "aluno@exemplo.com", senha: "mare2026" };
const form = document.querySelector("#form-login");
const email = form.email, senha = form.senha;

document.querySelector("#ver-senha").addEventListener("click", e => {
  const mostrar = senha.type === "password";
  senha.type = mostrar ? "text" : "password";
  e.target.textContent = mostrar ? "Ocultar senha" : "Mostrar senha";
  e.target.setAttribute("aria-pressed", mostrar);
});

function validar(campo, ok, msg) {
  campo.setAttribute("aria-invalid", !ok);
  document.querySelector("#erro-" + campo.name).textContent = ok ? "" : msg;
  return ok;
}

form.addEventListener("submit", e => {
  e.preventDefault();
  const okEmail = validar(email, email.validity.valid && email.value !== "", "Digite um e-mail no formato nome@dominio.com.");
  const okSenha = validar(senha, senha.value.length >= 8, "A senha precisa ter pelo menos 8 caracteres.");
  if (!okEmail) return email.focus();
  if (!okSenha) return senha.focus();
  if (email.value !== DEMO.email || senha.value !== DEMO.senha) {
    validar(senha, false, "E-mail ou senha incorretos. Use a conta de teste indicada acima.");
    return senha.focus();
  }
  try { sessionStorage.setItem("arena-logado", "1"); } catch {}
  location.href = "aluno.html";
});
