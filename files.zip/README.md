# Areia Viva – Aulas de Futevôlei

Site de demonstração de uma escola de futevôlei, feito com HTML, CSS e JavaScript puros (sem frameworks).

## Estrutura
- `index.html`: conteúdo e estrutura da página
- `style.css`: estilos, paleta de cores (variáveis CSS), modo escuro e alto contraste
- `script.js`: painel de acessibilidade, carrossel, login e formulário de contato

## Recursos
- Login de demonstração (validação de e-mail e senha, sem servidor)
- Carrossel com botões, pontos de navegação e pausa
- Painel de acessibilidade: claro/escuro, fonte maior/menor, alto contraste, sem animações (preferências salvas no navegador)
- Navegação por teclado, link "Pular para o conteúdo" e foco visível

## Paleta
Azul-petróleo `#0B3C49`, areia `#FBF1D9` e `#F3DFB0`, laranja `#FF7A1A`.

## Como executar
Abra `index.html` no navegador. Não há instalação.

## Como publicar no GitHub Pages
1. Crie um repositório público e envie os 4 arquivos.
2. Em Settings > Pages, escolha a branch `main` e a pasta `/ (root)`.
3. Acesse `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.
