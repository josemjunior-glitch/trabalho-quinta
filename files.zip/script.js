(function(){
  var root=document.documentElement,S={theme:null,fs:1,hc:false,rm:false};
  function save(){try{localStorage.setItem('av-a11y',JSON.stringify(S))}catch(e){}}
  function load(){try{var v=localStorage.getItem('av-a11y');if(v)S=Object.assign(S,JSON.parse(v))}catch(e){}}
  function apply(){
    if(S.theme)root.setAttribute('data-theme',S.theme);else root.removeAttribute('data-theme');
    root.style.setProperty('--fs',S.fs);
    S.hc?root.setAttribute('data-contrast','high'):root.removeAttribute('data-contrast');
    document.body.classList.toggle('noanim',S.rm);
    document.getElementById('hc').setAttribute('aria-pressed',S.hc);
    document.getElementById('rm').setAttribute('aria-pressed',S.rm);
    document.getElementById('tClaro').setAttribute('aria-pressed',S.theme==='light');
    document.getElementById('tEscuro').setAttribute('aria-pressed',S.theme==='dark');
  }
  function $(id){return document.getElementById(id)}
  load();apply();
  var panel=$('a11y'),btn=$('a11yBtn');
  btn.onclick=function(){var o=panel.classList.toggle('open');btn.setAttribute('aria-expanded',o)};
  $('tClaro').onclick=function(){S.theme='light';apply();save()};
  $('tEscuro').onclick=function(){S.theme='dark';apply();save()};
  $('fMais').onclick=function(){S.fs=Math.min(1.5,+(S.fs+.125).toFixed(3));apply();save()};
  $('fMenos').onclick=function(){S.fs=Math.max(.875,+(S.fs-.125).toFixed(3));apply();save()};
  $('hc').onclick=function(){S.hc=!S.hc;apply();save()};
  $('rm').onclick=function(){S.rm=!S.rm;apply();save()};
  $('reset').onclick=function(){S={theme:null,fs:1,hc:false,rm:false};apply();save()};
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&panel.classList.contains('open')){panel.classList.remove('open');btn.setAttribute('aria-expanded',false);btn.focus()}});

  /* carrossel */
  var sl=$('slides'),n=sl.children.length,i=0,timer=null,playing=!window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var dots=$('dots');
  for(var k=0;k<n;k++){(function(k){var b=document.createElement('button');b.setAttribute('aria-label','Ir para o slide '+(k+1));b.onclick=function(){go(k)};dots.appendChild(b)})(k)}
  function go(x){i=(x+n)%n;sl.style.transform='translateX(-'+i*100+'%)';Array.prototype.forEach.call(dots.children,function(d,j){d.setAttribute('aria-current',j===i)})}
  function start(){stop();if(playing)timer=setInterval(function(){go(i+1)},5000)}
  function stop(){clearInterval(timer)}
  function label(){var p=$('pp');p.textContent=playing?'❚❚':'▶';p.setAttribute('aria-label',playing?'Pausar rotação automática':'Retomar rotação automática')}
  $('prev').onclick=function(){go(i-1)};$('next').onclick=function(){go(i+1)};
  $('pp').onclick=function(){playing=!playing;label();playing?start():stop()};
  go(0);label();start();

  /* login */
  var dlg=$('loginDlg');
  $('openLogin').onclick=function(){$('lmsg').textContent='';dlg.showModal();$('le').focus()};
  $('closeLogin').onclick=function(){dlg.close()};
  $('loginForm').addEventListener('submit',function(e){
    e.preventDefault();
    var em=$('le').value.trim(),pw=$('lp').value,m=$('lmsg');
    if(!/^\S+@\S+\.\S+$/.test(em)){m.textContent='Digite um e-mail válido, como nome@email.com.';$('le').focus();return}
    if(pw.length<6){m.textContent='A senha precisa ter pelo menos 6 caracteres.';$('lp').focus();return}
    dlg.close();$('openLogin').textContent='Olá, '+em.split('@')[0];
  });

  /* contato */
  $('contactForm').addEventListener('submit',function(e){
    e.preventDefault();
    var m=$('cmsg'),nm=$('cn').value.trim(),em=$('cm').value.trim();
    if(!nm){m.textContent='Informe seu nome.';$('cn').focus();return}
    if(!/^\S+@\S+\.\S+$/.test(em)){m.textContent='Digite um e-mail válido.';$('cm').focus();return}
    m.textContent='Pronto, '+nm+'! Aula grátis solicitada para o nível '+$('cl').value+'.';
    e.target.reset();
  });
})();
